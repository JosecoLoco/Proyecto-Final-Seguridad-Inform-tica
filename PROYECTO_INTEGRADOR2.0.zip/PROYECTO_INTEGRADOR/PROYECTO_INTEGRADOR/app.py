from flask import Flask, request, jsonify, send_from_directory, redirect, url_for
import requests
from bs4 import BeautifulSoup
import whois
import dns.resolver
import re

app = Flask(__name__, static_url_path='', static_folder='static')

# Configuración para la API de Shodan (rellena con tu propia clave de API)
shodan_api_key = 'FmkDOxtjVkTknn29Yi5iphccR1fdfcC1'

def limpiar_url(url):
    # Eliminar protocolo (http:// o https://)
    url = re.sub(r'^https?:\/\/', '', url)
    # Eliminar cualquier barra final
    url = url.rstrip('/')
    return url

def obtener_datos_osint(url):
    activos = []
    id_activo = 1

    # Limpiar el URL
    dominio = limpiar_url(url)

    # Fuente 1: Enlaces en la página web
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        for link in soup.find_all('a'):
            href = link.get('href')
            texto = link.get_text(strip=True)
            if href and href.strip() and texto.strip():
                valor = valorizar_activo(href, texto)
                activo = {
                    "Id_Activo": id_activo,
                    "Tipo": "Enlace",
                    "Nombre": texto,
                    "Descripcion": href,
                    "Valoracion": valor
                }
                activos.append(activo)
                id_activo += 1

    # Fuente 2: Consultas WHOIS
    try:
        domain_info = whois.whois(dominio)
        if domain_info:
            valor = valorizar_activo("WHOIS", domain_info.domain_name)
            activo = {
                "Id_Activo": id_activo,
                "Tipo": "WHOIS",
                "Nombre": "WHOIS Information",
                "Descripcion": str(domain_info),
                "Valoracion": valor
            }
            activos.append(activo)
            id_activo += 1
    except Exception as e:
        print(f"Error obtaining WHOIS info: {e}")

    # Fuente 3: Consultas DNS
    try:
        answers = dns.resolver.resolve(dominio, 'A')
        for answer in answers:
            valor = valorizar_activo("DNS", str(answer))
            activo = {
                "Id_Activo": id_activo,
                "Tipo": "DNS",
                "Nombre": "DNS Record",
                "Descripcion": str(answer),
                "Valoracion": valor
            }
            activos.append(activo)
            id_activo += 1
    except Exception as e:
        print(f"Error obtaining DNS info: {e}")

    # Fuente 4: Información de Shodan
    try:
        shodan_response = requests.get(f"https://api.shodan.io/shodan/host/search?key={shodan_api_key}&query=hostname:{dominio}")
        if shodan_response.status_code == 200:
            shodan_data = shodan_response.json()
            for match in shodan_data['matches']:
                valor = valorizar_activo("Shodan", match['ip_str'])
                activo = {
                    "Id_Activo": id_activo,
                    "Tipo": "Shodan",
                    "Nombre": match['ip_str'],
                    "Descripcion": f"IP: {match['ip_str']}, Org: {match.get('org', 'N/A')}, ISP: {match.get('isp', 'N/A')}",
                    "Valoracion": valor
                }
                activos.append(activo)
                id_activo += 1
    except Exception as e:
        print(f"Error obtaining Shodan info: {e}")

    return activos

def valorizar_activo(href, texto):
    confidencialidad = calcular_confidencialidad(href, texto)
    integridad = calcular_integridad(href, texto)
    disponibilidad = calcular_disponibilidad(href, texto)
    impacto = calcular_impacto(href, texto)
    
    valor_total = confidencialidad + integridad + disponibilidad + impacto
    return valor_total

def calcular_confidencialidad(href, texto):
    confidencialidad_keywords = ['secure', 'private', 'internal', 'confidential']
    if any(keyword in href.lower() for keyword in confidencialidad_keywords):
        return 80
    if any(keyword in texto.lower() for keyword in confidencialidad_keywords):
        return 60
    return 20

def calcular_integridad(href, texto):
    integridad_keywords = ['official', 'verified', 'trusted', 'authentic']
    if any(keyword in texto.lower() for keyword in integridad_keywords):
        return 70
    if any(keyword in href.lower() for keyword in integridad_keywords):
        return 50
    return 15

def calcular_disponibilidad(href, texto):
    disponibilidad_keywords = ['always', '24/7', 'available', 'uptime']
    if any(keyword in texto.lower() for keyword in disponibilidad_keywords):
        return 60
    if any(keyword in href.lower() for keyword in disponibilidad_keywords):
        return 40
    return 10

def calcular_impacto(href, texto):
    impacto_keywords = ['critical', 'important', 'high', 'significant']
    if any(keyword in texto.lower() for keyword in impacto_keywords):
        return 90
    if any(keyword in href.lower() for keyword in impacto_keywords):
        return 70
    return 25

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'hola.html')

@app.route('/resultados')
def resultados():
    return send_from_directory(app.static_folder, 'resultados.html')

@app.route('/buscar', methods=['POST'])
def buscar():
    data = request.form
    url = data.get('url')
    if not url:
        return jsonify({"error": "URL es requerida"}), 400
    
    datos_osint = obtener_datos_osint(url)
    global resultados_cache
    resultados_cache = datos_osint
    return redirect(url_for('resultados'))

@app.route('/obtener_resultados')
def obtener_resultados():
    global resultados_cache
    return jsonify(resultados_cache)

if __name__ == '__main__':
    resultados_cache = []  # Inicializar la variable de resultados
    app.run(debug=True)
